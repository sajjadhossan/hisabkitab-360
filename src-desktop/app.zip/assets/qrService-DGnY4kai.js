import{r as e}from"./rolldown-runtime-hePW80VL.js";import{r as t}from"./vendor-barcode-scanner-C-AFzIuV.js";var n=e(t()),r=async(e,t={})=>{try{return await n.toDataURL(e,{width:t.width||300,margin:t.margin===void 0?1:t.margin,color:{dark:t.darkColor||`#000000`,light:t.lightColor||`#ffffff`},errorCorrectionLevel:`M`})}catch(e){return console.warn(`QR code generation warning:`,e),null}},i=(e,t)=>{if(!e)return`HisabKitab 360 Official Receipt`;let n=t?.companyName||`হিসাব কিতাব ৩৬০`,r=t?.phone||``,i=t?.address||``,a=Number(e.grandTotal)||0,o=e.paidAmount===void 0?e.status===`paid`?a:0:Number(e.paidAmount),s=e.dueAmount===void 0?Math.max(0,a-o):Number(e.dueAmount),c=s===0?`পরিশোধিত (PAID)`:`বকেয়া (DUE ৳${s.toLocaleString()})`,l=(e.items||[]).slice(0,5).map(e=>`• ${e.name} (${e.qty} x ৳${Number(e.price).toLocaleString()})`).join(`
`),u=(e.items||[]).length>5?`\n...আরও ${e.items.length-5} টি পণ্য`:``,d=typeof window<`u`&&window.location.hostname!==`localhost`&&window.location.hostname!==`127.0.0.1`?`${window.location.origin}${window.location.pathname}?verify=${encodeURIComponent(e.id)}`:t?.website?`https://${t.website.replace(/^https?:\/\//,``)}`:``;return[`🧾 ${n}`,i?`📍 ${i}`:``,r?`📞 ${r}`:``,`────────────────────`,`মেমো নং: #${e.id}`,`তারিখ: ${e.date||new Date().toISOString().split(`T`)[0]}`,`ক্রেতা: ${e.customerName||`সাধারণ ক্রেতা`} ${e.customerPhone?`(${e.customerPhone})`:``}`,`────────────────────`,l?`পণ্যসমূহ:\n${l}${u}\n────────────────────`:``,`মোট বিল: ৳${a.toLocaleString()}`,`পরিশোধ: ৳${o.toLocaleString()}`,`স্ট্যাটাস: ${c}`,d?`────────────────────\n🌐 ভেরিফিকেশন: ${d}`:``,`✓ হিসাবকিতাব ৩৬০ ডিজিটাল ভেরিফাইড মেমো`].filter(Boolean).join(`
`)},a=(e,t)=>{if(!e)return typeof window<`u`?window.location.href:``;let n=Number(e.grandTotal)||0,r=e.paidAmount===void 0?e.status===`paid`?n:0:Number(e.paidAmount),i=e.dueAmount===void 0?Math.max(0,n-r):Number(e.dueAmount),a={id:e.id,date:e.date,customerName:e.customerName,customerPhone:e.customerPhone||``,grandTotal:n,paidAmount:r,dueAmount:i,status:e.status,paymentMethod:e.paymentMethod,companyName:t?.companyName||`HisabKitab 360`,companyPhone:t?.phone||``,companyAddress:t?.address||``,items:(e.items||[]).map(e=>({name:e.name,qty:e.qty,price:e.price,subtotal:e.subtotal||e.price*e.qty}))};try{let t=JSON.stringify(a),n=encodeURIComponent(btoa(unescape(encodeURIComponent(t))));return`${window.location.origin+window.location.pathname}?verify=${encodeURIComponent(e.id)}&data=${n}`}catch{return`${window.location.origin+window.location.pathname}?verify=${encodeURIComponent(e.id)}`}},o=e=>{if(!e)return null;try{let t=decodeURIComponent(escape(atob(decodeURIComponent(e))));return JSON.parse(t)}catch(e){return console.warn(`Could not decode invoice token:`,e),null}},s=e=>{if(!e)return``;let t=e.replace(/[^0-9]/g,``);return t.startsWith(`01`)&&t.length===11?t=`88`+t:t.startsWith(`1`)&&t.length===10&&(t=`880`+t),t},c=(e,t,n=`bn`)=>{if(!e)return``;let r=t?.companyName||`হিসাব কিতাব ৩৬০ স্টোর`,i=t?.phone||``,o=Number(e.grandTotal)||0,s=e.paidAmount===void 0?e.status===`paid`?o:0:Number(e.paidAmount),c=e.dueAmount===void 0?Math.max(0,o-s):Number(e.dueAmount),l=a(e,t),u=(e.items||[]).map((e,t)=>`${t+1}. ${e.name} (${e.qty} টি) = ৳${(e.price*e.qty).toLocaleString()}`).join(`
`);return n===`bn`?`🧾 *ডিজিটাল ক্যাশমেমো ও ইনভয়েস*
━━━━━━━━━━━━━━━━━━
🏪 *প্রতিষ্ঠান:* ${r}
📞 *হটলাইন:* ${i}
📄 *মেমো নং:* #${e.id}
📅 *তারিখ:* ${e.date}
👤 *গ্রাহক:* ${e.customerName||`সাধারণ ক্রেতা`} ${e.customerPhone?`(${e.customerPhone})`:``}
━━━━━━━━━━━━━━━━━━
🛍️ *ক্রয়কৃত পণ্যসমূহ:*
${u||`পণ্য বিস্তারিত বিল ভিউতে দেখুন`}
━━━━━━━━━━━━━━━━━━
💵 *সর্বমোট বিল:* ৳${o.toLocaleString()}
✅ *পরিশোধ:* ৳${s.toLocaleString()}
${c>0?`⚠️ *অবশিষ্ট বকেয়া:* ৳${c.toLocaleString()}`:`🎉 *স্ট্যাটাস:* সম্পূর্ণ পরিশোধিত (PAID)`}
━━━━━━━━━━━━━━━━━━
🔍 *স্মার্টফোনে রসিদ যাচাই ও কপি পেতে লিংকে চাপ দিন:*
${l}

🙏 আমাদের সাথে কেনাকাটা করার জন্য ধন্যবাদ!`:`🧾 *OFFICIAL DIGITAL INVOICE*
━━━━━━━━━━━━━━━━━━
🏪 *Store:* ${r}
📞 *Phone:* ${i}
📄 *Invoice:* #${e.id}
📅 *Date:* ${e.date}
👤 *Customer:* ${e.customerName||`Walk-in`} ${e.customerPhone?`(${e.customerPhone})`:``}
━━━━━━━━━━━━━━━━━━
🛍️ *Purchased Items:*
${u||`View full breakdown in link`}
━━━━━━━━━━━━━━━━━━
💵 *Grand Total:* ৳${o.toLocaleString()}
✅ *Paid Amount:* ৳${s.toLocaleString()}
${c>0?`⚠️ *Remaining Due:* ৳${c.toLocaleString()}`:`🎉 *Status:* FULLY PAID`}
━━━━━━━━━━━━━━━━━━
🔍 *Verify official digital receipt online:*
${l}

Thank you for shopping with us!`},l=(e,t,n=`bn`)=>{if(!e)return``;let r=t?.companyName||`হিসাব কিতাব ৩৬০`,i=Number(e.totalCashSales)||0,a=Number(e.totalDigitalSales)||0,o=i+a,s=Number(e.openingFloat)||0,c=Number(e.closingCash||e.actualCash)||0,l=s+i,u=c-l,d=`মিল রয়েছে (✓)`;return u>0?d=`অতিরিক্ত +৳${u.toLocaleString()}`:u<0&&(d=`ঘাটতি -৳${Math.abs(u).toLocaleString()}`),n===`bn`?`📊 *কাউন্টার শিফট হ্যান্ডওভার ও হিসাব রিপোর্ট*
━━━━━━━━━━━━━━━━━━━━
🏢 *প্রতিষ্ঠান:* ${r}
📍 *শাখা:* ${e.branchName||`প্রধান শাখা`}
💻 *কাউন্টার:* ${e.counterName||`কাউন্টার ০১`}
👤 *দায়িত্বপ্রাপ্ত ক্যাশিয়ার:* ${e.cashierName||`ক্যাশিয়ার`}
📅 *তারিখ ও সময়:* ${e.timestamp||new Date().toLocaleString()}
━━━━━━━━━━━━━━━━━━━━
💵 *প্রারম্ভিক ক্যাশ (Opening Float):* ৳${s.toLocaleString()}
🛒 *মোট নগদ বিক্রয়:* ৳${i.toLocaleString()}
📱 *মোট ডিজিটাল বিক্রয়:* ৳${a.toLocaleString()}
📈 *সর্বমোট বিক্রয়:* ৳${o.toLocaleString()} (${e.totalTransactions||0} টি মেমো)
━━━━━━━━━━━━━━━━━━━━
💼 *ড্রয়ারে হিসেবকৃত মোট ক্যাশ:* ৳${c.toLocaleString()}
🎯 *ড্রয়ারে প্রত্যাশিত ক্যাশ:* ৳${l.toLocaleString()}
⚖️ *ক্যাশ স্ট্যাটাস:* ${d}
${e.note?`📝 *ক্যাশিয়ার নোট:* ${e.note}\n`:``}━━━━━━━━━━━━━━━━━━━━
✓ হিসাবকিতাব ৩৬০ ডিজিটাল পিওএস সিকিউর হ্যান্ডওভার`:`📊 *COUNTER SHIFT CLOSING REPORT*
━━━━━━━━━━━━━━━━━━━━
🏢 *Company:* ${r}
📍 *Branch:* ${e.branchName||`Main Branch`}
💻 *Counter:* ${e.counterName||`Counter 01`}
👤 *Cashier:* ${e.cashierName||`Cashier`}
📅 *Date & Time:* ${e.timestamp||new Date().toLocaleString()}
━━━━━━━━━━━━━━━━━━━━
💵 *Opening Float:* ৳${s.toLocaleString()}
🛒 *Cash Sales:* ৳${i.toLocaleString()}
📱 *Digital Sales:* ৳${a.toLocaleString()}
📈 *Total Revenue:* ৳${o.toLocaleString()} (${e.totalTransactions||0} transactions)
━━━━━━━━━━━━━━━━━━━━
💼 *Actual Drawer Cash:* ৳${c.toLocaleString()}
🎯 *Expected Cash:* ৳${l.toLocaleString()}
⚖️ *Discrepancy:* ${d}
${e.note?`📝 *Note:* ${e.note}\n`:``}━━━━━━━━━━━━━━━━━━━━
✓ Verified by HisabKitab 360 POS System`},u=(e,t,n=`v2.0.0`)=>{let r=e?.name||e?.email||`নতুন ব্যবহারকারী`;return`হ্যালো HisabKitab 360 সাপোর্ট টিম 👋
আমি *${t||`আমার প্রতিষ্ঠান`}* (${r}) থেকে যোগাযোগ করছি।

সফটওয়্যারটির (${n}) ব্যবহারের বিষয়ে আমার কিছু কারিগরি ও ব্যবহারিক সহায়তা প্রয়োজন। অনুগ্রহ করে আমাকে সহযোগিতা করবেন কি?

ধন্যবাদ!`};export{l as a,s as c,c as i,o as n,i as o,u as r,r as s,a as t};